using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using GravityBot;

public class Punch : BoundingBoxCollision.GameObject
{

    public TextureManager t;
    public TextureManager t2;
    public Player p;
    public Boolean grow = true;
    int frames = 1;

    public Punch(Texture2D texture, Vector2 position, float lenX, float lenY, ContentManager content , Player p)
        : base(texture, position, lenX, lenY)
	{
        //16+6*8
        this.texture = texture;
        this.Position = position;
        this.lenX = lenX;
        this.lenY = lenY;

        this.p = p;
        t = new TextureManager("punching_glove", 10, 0, content);
        t2 = new TextureManager("punching_glove", 10, 0, content,true);
        grow = true;
        frames = 1;
        lenY = 24;
        lenX = 16;

	}

    public void update()
    {
        ajustPosition();

        if (grow)
        {
            if (t.needupdate())
            {
                frames = frames + 1;
                lenX += 8;
                if (frames > 9)
                {
                    this.texture = t2.getframe();
                    grow = false;
                    lenX = 64;
                    frames = 0;
                }

                this.texture = t.getframe();
            }
        }
        else
        {
            if (t2.needupdate())
            {
                frames += 1;
                lenX -= 8;

                if (frames > 9)
                {
                    this.Position.X = 0;
                    p.killPunch();
                }
                else
                {
                    this.texture = t2.getframe();
                }
            }
        }

        checkCollision();
    }

    public void ajustPosition()
    {
        this.Position.X = p.Position.X + p.lenX;
        this.Position.Y = p.Position.Y - (p.lenY/2)+8;
    }

        //Destroy object
    public void checkCollision()
    {
            float x =this.Position.X;
            float lenX = this.texture.Width;
            float y =this.Position.Y;
            float lenY = this.texture.Height;

            for (int i = 0; i < Game1.blockList.Count(); i++)
            {
                Block b = Game1.blockList[i];

                //if (b.solid && this.BoundingBox.Intersects(b.BoundingBox))
                if (b.solid && b.breakable && Game1.getCollision(this, b))
                {
                    //b.Position.X = 0;
                    Game1.blockList.Remove(b);
                    b = null;

                    Game1.crateS.play_once();

                    //Block bonus = new Block()
                }
            }
    }


    


}

