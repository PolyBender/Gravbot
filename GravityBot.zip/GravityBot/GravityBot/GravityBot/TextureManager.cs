using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;



  public  class TextureManager
    {
        public List<Texture2D> texture;
        public ContentManager content;
        int frame = 0;
        int frame_max;
        int update_temp = 0;
        int update_max;
        Boolean inverted = false;

        public TextureManager(string generic_file_name, int number_of_images, int number_of_frames_between_updates, ContentManager content)
        {
            this.content = content;
            frame_max = number_of_images;
            update_max = number_of_frames_between_updates;

            texture = new List<Texture2D>();

            for (int i = 0; i < number_of_images; i++)
            {
                texture.Add(content.Load<Texture2D>(generic_file_name + Convert.ToString(i+1)));
            }
        }

        public TextureManager(string generic_file_name, int number_of_images, int number_of_frames_between_updates, ContentManager content, Boolean inverted)
        {
            this.content = content;
            frame_max = number_of_images;
            update_max = number_of_frames_between_updates;

            texture = new List<Texture2D>();

            this.inverted = inverted;

            if (!inverted)
            {
                for (int i = 0; i < number_of_images; i++)
                {
                    texture.Add(content.Load<Texture2D>(generic_file_name + Convert.ToString(i + 1)));
                }
            }
            else
            {
                for (int i = number_of_images-1; i >=0; i--)
                {
                    texture.Add(content.Load<Texture2D>(generic_file_name + Convert.ToString(i + 1)));
                }
            }
        }

        public Texture2D getframe()
        {
            return texture[frame];
        }

        public bool needupdate()
        {
            if (update_temp >= update_max)
            {
                frame++;
                if (frame > frame_max - 1)
                {
                    frame = 0;
                }
                update_temp = 0;
                return true;
            }
            update_temp++;
            return false;
        }

        public void reset()
        {
            update_temp = 0;
            frame = 0;
        }
    }
