using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using BoundingBoxCollision;

static class World
{
    static public float x = 0;
    //Map m;

    static public float vx = 0f;
    static public float ax = 0.075f;
    static public float maxSpeedX = 4;
    static public float maxX;

    static public GameObject background;
    static public float backVx = 3.75f;

    static public void update()
    {
        if (x < maxX)
        {
            vx += ax;

            if (World.vx > World.maxSpeedX)
                World.vx = World.maxSpeedX;

            World.x += World.vx;

            background.Position.X += backVx;
        }

    }

    static public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(background.texture, new Vector2(background.Position.X- World.x, 0), Color.White);
    }

}
