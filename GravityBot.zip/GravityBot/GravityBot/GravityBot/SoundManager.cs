using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Content;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;



public class SoundManager
{
    SoundEffect sound;
    SoundEffectInstance Instance;

    public SoundManager(string soundfile, ContentManager content)
    {
        sound = content.Load<SoundEffect>(soundfile);
        Instance = sound.CreateInstance();
        Instance.IsLooped = false;
    }

    public void background_play()
    {
        if ((Instance.State != SoundState.Playing) && (Instance.IsLooped == false))
        {
            Instance.IsLooped = true;
            Instance.Play();
        }
    }

    public void play_once()
    {
        if (Instance.State != SoundState.Playing)
        {
            //Instance.IsLooped = false;
            Instance.Play();

        }
    }

    public void stop_sound()
    {
        if (Instance.State == SoundState.Playing)
        {
            Instance.Stop();
        }
    }

    public void pause_sound()
    {
        if (Instance.State == SoundState.Playing)
        {
            Instance.Pause();
        }
    }

    public void resume_sound()
    {
        if (Instance.State == SoundState.Paused)
        {
            Instance.Resume();
        }
    }

    public void adjust_volume(int volume)
    {
        Instance.Volume = volume;
    }
}


