using System;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.IsolatedStorage;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;


public class Map
{
    public string[,] grid;
    public Vector2 position_initial;
    public int gravity;
    public int height;
    public int width;
    public int style;
    public string[] block_line;

    //constructor
    public Map()
    {

    }

    //read grid dans grid
    public void read_grid(string filename)
    {
        Stream testpath = TitleContainer.OpenStream("Content/levels/" + filename);
        //Stream testpath = TitleContainer.OpenStream("Content/"+filename);
        StreamReader reader = new StreamReader(testpath);

        width = Convert.ToInt32(reader.ReadLine());
        height = Convert.ToInt32(reader.ReadLine());
        position_initial.X = Convert.ToInt32(reader.ReadLine());
        position_initial.Y = Convert.ToInt32(reader.ReadLine());
        gravity = Convert.ToInt32(reader.ReadLine());
        style = Convert.ToInt32(reader.ReadLine());
        grid = new string[height, width];

        for (int i = 0; i < height; i++)
        {
            block_line = reader.ReadLine().Split(new Char[] { ',' });
            for (int j = 0; j < width; j++)
            {
                grid[i, j] = block_line[j];
            }
        }
    }
}