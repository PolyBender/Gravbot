using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using BoundingBoxCollision;

public class Block : BoundingBoxCollision.GameObject
{
    public Boolean solid; //Si le block fait des collisions
    public Boolean breakable;
    public Boolean killer;

    public Boolean bonus = false;
    public int points =0;

    //public Boolean horizontalCollision;

    public Block(Texture2D texture, Vector2 position, float lenX, float lenY, Boolean solid, Boolean breakable, Boolean killer)
        : base(texture, position,lenX,lenY)
    {
        this.solid = solid;
        this.breakable = breakable;
        this.killer = killer;
    }

    public void update()
    {

    }
}
