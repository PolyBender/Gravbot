﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

using GravityBot;

using BoundingBoxCollision;

public class Player : BoundingBoxCollision.GameObject
{
   public float vx;
   public float vy;

   public float ax;
   public float ay;

   public float punchCooldown = 0;
   public float punchCooldownMax = 5;

   public float maxSpeedX = 4;
   public float maxSpeedX2 = 6;

   public float maxSpeedY = 11.5f;

   public TextureManager t;
   public TextureManager t2;
   public TextureManager t3;
   public TextureManager t4;

   public Boolean walking = false;
   public int walkWait = 3;

    public Boolean needUpdate = false;

    public Punch pu;

    public const float FACTEUR_DE_REBOND = -0.2f;
    public const float REBOND_H = -0.5f;
    //public const float FACTEUR_DE_REBOND = 0;

    public Player(Texture2D texture, Vector2 position, float lenX, float lenY, float vx, float vy, float ax, float ay, ContentManager content)
        : base(texture, position, lenX, lenY)
	{
        this.vx = vx;
        this.vy = vy;
        this.ax = ax;
        this.ay = ay;

        t = new TextureManager("robot", 2, 6, content);
        t2 = new TextureManager("downrobot", 2, 6, content);
        t3 = new TextureManager("robot_punch", 2, 6, content);
        t4 = new TextureManager("downrobot_punch", 2, 6, content);

	}

    public void update()
    {
        vx += ax;
        vy += ay;

        /*if (needUpdate)
        {
            needUpdate = false;
            if (ay > 0)
                if(this.pu != null)
                    this.texture = t4.getframe();
                else
                    this.texture = t2.getframe();
            else
                if (this.pu != null)
                    this.texture = t3.getframe();
                else
                    this.texture = t.getframe();
        }*/

        if (this.Position.X - 150 < World.x)
        {
            if (this.vx > this.maxSpeedX2)
                this.vx = this.maxSpeedX2;
        }
        else
        {
            if (this.vx > this.maxSpeedX)
            {
                if (this.vx-this.ax < this.maxSpeedX)
                    this.vx = this.maxSpeedX;
                else
                    this.vx-=2*ax;
            }

        }



        if (this.vy > this.maxSpeedY)
            this.vy = this.maxSpeedY;

        if (this.vy < (this.maxSpeedY)*-1)
            this.vy = this.maxSpeedY*-1;

        /*if (this.vy < 0.01f && this.vx > -0.01f)
            this.vy = 0f;*/

        //Console.Out.WriteLine(vy.ToString());
        Position.X += vx;
        Position.Y -= vy;

        if (pu != null)
            pu.update();

        checkCollision();

        if (pu != null)
            pu.ajustPosition();

        //Animation

        if (ay > 0)
        {
            if (this.pu != null)
            {
                if (t4.needupdate())
                    this.texture = t4.getframe();
            }
            else
            {
                if (t2.needupdate())
                    this.texture = t2.getframe();
            }
        }
        else
        {
            if (this.pu != null)
            {
                if (t3.needupdate())
                    this.texture = t3.getframe();
            }
            else
            {
                if (t.needupdate())
                    this.texture = t.getframe();
            }
        }

       /* if (ay < 0)
        {
            if (t.needupdate())
            {
                this.texture = t.getframe();
            }
        }
        else
        {
            if (t2.needupdate())
            {
                this.texture = t2.getframe();
            }
        }*/

    }

    public void killPunch()
    {
        pu = null;
    }

    public void resetPlayer()
    {
        this.Position.X = 50;
        this.Position.Y = 50;
        this.vx = 3;
        this.vy = 0;
        this.ax = 0.1f;
        this.pu = null;
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Draw(texture, new Vector2(Position.X - World.x, Position.Y-24), Color.White);
        if (pu!=null)
            spriteBatch.Draw(pu.texture, new Vector2(pu.Position.X - World.x, pu.Position.Y+4), Color.White);
    }

    public void checkCollision()
    {
        float x =this.Position.X;
        float lenX = this.texture.Width;
        float y =this.Position.Y;
        float lenY = this.texture.Height;

        bool collision = false; 

        for (int i = 0; i < Game1.blockList.Count(); i++)
        {
            Block b = Game1.blockList[i];

            //if (b.solid && this.BoundingBox.Intersects(b.BoundingBox))
            if (b.solid && !b.killer && Game1.getCollision(this, b))
            {
                collision = true;

                if (!walking)
                {
                    walkWait = 3;
                    walking = true;
                    Game1.walkS.background_play();
                }
                

                float bx =b.Position.X;
                float blenX = b.texture.Width;
                float by =b.Position.Y;
                float blenY = b.texture.Height;

                //player comes from top
                if (y > by - blenY && y - lenY < by - blenY)
                {
                    if (Math.Abs(y-(by-blenY)) < 12)
                    {
                        this.Position.Y = by - blenY;
                        this.vy *= FACTEUR_DE_REBOND;
                    }
                    else
                    {
                        if (x + lenX > blenX && x < bx)
                        {
                            this.Position.X = bx - this.lenX-1;
                            this.vx *= REBOND_H;
                        }
                    }
                }
                else if (y-lenY<by && y>by)
                {
                    if (Math.Abs(y-(by+lenY)) < 12)
                    {
                        this.Position.Y = by + lenY;
                        this.vy *= FACTEUR_DE_REBOND;
                    }
                    else
                    {
                        if (x + lenX > blenX && x < bx)
                        {
                            this.Position.X = bx - this.lenX-1;
                            this.vx *= REBOND_H;
                        }
                    }
                }
                /*else
                {
                    if (x + lenX > blenX && x < bx)
                    {
                        this.Position.X = bx - this.lenX;
                    }
                }*/
            }
            else if (b.solid && b.killer && Game1.getCollision(this, b))
            {
                Game1.resetWorld();
                this.resetPlayer();
            }
        }

        if (!collision)
        {
            walkWait--;
            if (walkWait <= 0)
            {
                if (walking)
                {
                    walking = false;
                    Game1.walkS.stop_sound();
                }
            }
        }

    }
}
