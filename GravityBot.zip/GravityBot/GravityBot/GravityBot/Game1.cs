using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework.Media;

using BoundingBoxCollision;

namespace GravityBot
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        SoundManager menuSound;
        SoundManager level1S;
        SoundManager level4S;
        SoundManager level5S;
        SoundManager level6S;
        SoundManager up;
        SoundManager down;
        SoundManager punchS;
        SoundManager deathS;

        public static SoundManager crateS;
        public static SoundManager walkS;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Player p;
        int currentLevel = 1;
        Map m;

        Boolean pause = true;
        int currentMode = 1;
        GameObject menu;

        bool touching = false;
        float sumX = 0;
        float sumY = 0;
        float startX;
        float startY;

        const float SLIDE_MIN = 15;
        const float BACKGROUND_INITIAL_X = -150;

        Texture2D punchTexture;
        Texture2D playerTexture;
        Texture2D menuTexture;
        Texture2D introTexture;
        Texture2D controlsTexture;

        Texture2D lvl1Texture;
        Texture2D lvl2Texture;
        Texture2D lvl3Texture;
        Texture2D lvl4Texture;
        Texture2D lvl5Texture;
        Texture2D lvl6Texture;
        Texture2D lvl7Texture;

        Texture2D blockTexture;
        Texture2D blockTexture2;
        Texture2D blockTexture3;

        public static List<Block> blockList;
        //public static List<Block> blockListDeleted;



        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            // Frame rate is 30 fps by default for Windows Phone.
            TargetElapsedTime = TimeSpan.FromTicks(200000);
            //TargetElapsedTime = TimeSpan.FromTicks(1000000);

            // Extend battery life under lock.
            InactiveSleepTime = TimeSpan.FromSeconds(1);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //Loading screens
            menuTexture = Content.Load<Texture2D>("Main_menu");
            introTexture = Content.Load<Texture2D>("intro");
            controlsTexture = Content.Load<Texture2D>("explain");

            lvl1Texture = Content.Load<Texture2D>("level1");
            lvl2Texture = Content.Load<Texture2D>("level2");
            lvl3Texture = Content.Load<Texture2D>("level3");
            lvl4Texture = Content.Load<Texture2D>("level4");
            lvl5Texture = Content.Load<Texture2D>("level5");
            lvl6Texture = Content.Load<Texture2D>("level6");
            lvl7Texture = Content.Load<Texture2D>("level7");

            playerTexture = Content.Load<Texture2D>("robot2");
            punchTexture = Content.Load<Texture2D>("punching_glove1");

            blockTexture = Content.Load<Texture2D>("tile1");
            blockTexture2 = Content.Load<Texture2D>("tile2");
            blockTexture3 = Content.Load<Texture2D>("tile3");

            menuSound = new SoundManager("Retribution", Content);
            level1S = new SoundManager("Syntheticity", Content);
            level4S = new SoundManager("Ominosity", Content);
            level5S = new SoundManager("WildWaters", Content);
            level6S = new SoundManager("BloodyTears", Content);

            up = new SoundManager("gravityup", Content);
            down = new SoundManager("gravitydown", Content);
            punchS = new SoundManager("punch", Content);
            deathS = new SoundManager("death", Content);

            crateS = new SoundManager("boom", Content);
            walkS = new SoundManager("walk", Content);

            menuSound.background_play();

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            HandleTouches();

            if (!pause)
            {
                // TODO: Add your update logic here

                World.update();
                p.update();

                for (int i = 0; i < blockList.Count; i++)
                {
                    blockList[i].update();
                }

                killCheck();
            }
            else
            {
                if (menu == null)
                {
                    if (currentMode == 1)
                        menu = new GameObject(menuTexture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 2)
                        menu = new GameObject(introTexture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 3)
                        menu = new GameObject(controlsTexture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 4)
                        menu = new GameObject(lvl1Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 5)
                        menu = new GameObject(lvl2Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 6)
                        menu = new GameObject(lvl3Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 7)
                        menu = new GameObject(lvl4Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 8)
                        menu = new GameObject(lvl5Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 9)
                        menu = new GameObject(lvl6Texture, new Vector2(0, 0), 0, 0);
                    else if (currentMode == 10)
                        menu = new GameObject(lvl7Texture, new Vector2(0, 0), 0, 0);
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            //base.Draw(gameTime);

            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            if (!pause)
            {

                World.background.Draw(spriteBatch);

                for (int i = 0; i < blockList.Count; i++)
                {
                    if (blockList[i].Position.X - World.x >= -24 && blockList[i].Position.X - World.x <= 824)
                        blockList[i].Draw(spriteBatch);
                }

                p.Draw(spriteBatch);

            }
            else
            {
                if (menu!= null && currentMode != 0)
                {
                    menu.Draw(spriteBatch,false);
                }



            }

            spriteBatch.End();



            base.Draw(gameTime);
        }

        public static Boolean getCollision(int x1, int y1, float lenx1, float leny1, int x2, int y2, float lenx2, float leny2)
        {
            return !(x2 > x1 + lenx1 || x1 > x2 + lenx2 || y2 < y1 - leny1 || y1 < y2 - leny2);
        }
        public static Boolean getCollision(GameObject o1, GameObject o2)
        {
            return getCollision(
                (int)Math.Round(o1.Position.X),
                (int)Math.Round(o1.Position.Y),
                (int)Math.Round(o1.lenX),
                (int)Math.Round(o1.lenY),
                (int)Math.Round(o2.Position.X),
                (int)Math.Round(o2.Position.Y),
                (int)Math.Round(o2.lenX),
                (int)Math.Round(o2.lenY));
        }

        public Map loadLevel()
        {
            Map ma = new Map();
            //ma.read_grid("lvl"+level.ToString()+".txt");
            ma.read_grid("lvl"+currentLevel.ToString()+".txt");
            //ma.read_grid("test_lvl");

            return ma;
        }

        public static void resetWorld()
        {
            World.x = 0;
            World.background.Position.X = BACKGROUND_INITIAL_X;
            World.vx = 0f;
        }


        public void killCheck()
        {
            if ((p.Position.X + 200 < World.x || p.Position.Y < -48 || p.Position.Y > 528) && p.Position.X-800<World.x)
            {
                //reset the world

                World.x = 0;
                World.background.Position.X = BACKGROUND_INITIAL_X;
                World.vx = 0f;

                //reset the player
                deathS.play_once();
                p.resetPlayer();

                //reset the map

            }
            else if (p.Position.X > World.x + 850)
            {
                nextLevel();
            }
        }

        public void setBackground(int level)
        {
            if (World.background != null)
            {
                World.background = null;
            }

            Texture2D backGroundTexture = null;
            if (currentLevel <= 3)
                backGroundTexture = Content.Load<Texture2D>("back1");
            else if (currentLevel == 4)
                backGroundTexture = Content.Load<Texture2D>("back2");
            else if (currentLevel == 5)
                backGroundTexture = Content.Load<Texture2D>("back5");
            else if (currentLevel == 6)
                backGroundTexture = Content.Load<Texture2D>("back6");
            else if (currentLevel == 7)
                backGroundTexture = Content.Load<Texture2D>("back7");

            World.background = new GameObject(backGroundTexture, new Vector2(0, 1));
            World.background.Position.X = BACKGROUND_INITIAL_X;
        }

        public void nextLevel()
        {
            currentLevel++;

            if (currentLevel >= 8)
            {
                pause = true;
            }
            else
            {
                currentMode = currentLevel + 3;
                menu = null;
                pause = true;
                prepareLevel(currentLevel);
            }
        }

        public void prepareLevel(int level)
        {
            m = loadLevel();
            setBackground(currentLevel);

            //Cr�ation des blocks
            //Loading level

            World.maxX = (m.width - 100 / 3 - 1) * 24;

            blockList = new List<Block>();


            for (int i = 0; i < m.height; i++)
            {
                for (int j = 0; j < m.width; j++)
                {
                    if (m.grid[i, j] == "1")
                    {
                        Block b = new Block(blockTexture, new Vector2(j * (24), i * (24)), 24, 24, true, false,false);
                        blockList.Add(b);
                    }
                    else if (m.grid[i, j] == "3")
                    {
                        Block b = new Block(blockTexture2, new Vector2(j * (24), i * (24)), 24, 24, true, true,false);
                        blockList.Add(b);
                    }
                    else if (m.grid[i, j] == "7")
                    {
                        Block b = new Block(blockTexture3, new Vector2(j * (24), i * (24)), 24, 24, true, false,true);
                        blockList.Add(b);
                    }
                }

            }

            p = new Player(playerTexture, new Vector2(50, 50), 24, 48, 3, 0, 0.1f, -0.5f, Content);

        }

        private void HandleTouches()
        {
            TouchCollection touches = TouchPanel.GetState();
            if (!touching && touches.Count > 0)
            {
                foreach (TouchLocation tl in touches)
                {
                    if (!pause)
                    {
                        if (tl.State == TouchLocationState.Pressed)
                        {
                            //touching = true;
                            sumX = 0;
                            sumY = 0;
                            startX = tl.Position.X;
                            startY = tl.Position.Y;
                        }
                        else if (tl.State == TouchLocationState.Moved)
                        {
                            sumX = startX - tl.Position.X;
                            sumY = startY - tl.Position.Y;
                        }
                        else if (tl.State == TouchLocationState.Released)
                        {
                            if (Math.Abs(sumX) >= SLIDE_MIN || Math.Abs(sumY) >= SLIDE_MIN)
                            {

                                //Punch
                                if (Math.Abs(sumX) > Math.Abs(sumY))
                                {
                                    if (p.pu == null && sumX < 0)
                                    {

                                        //temp
                                        //nextLevel();

                                        punchS.play_once();
                                        p.pu = new Punch(punchTexture, new Vector2(p.Position.X + p.lenX, p.Position.Y - p.lenY / 2), 16, 16, Content, p);
                                        p.needUpdate = true;
                                    }
                                }
                                else //Gravity change
                                {
                                    p.needUpdate = true;

                                    //Up
                                    if (sumY > 0)
                                    {
                                        if (p.ay < 0)
                                        {
                                            p.ay *= -1;
                                            up.play_once();
                                        }

                                    }
                                    else //Down
                                    {
                                        if (p.ay > 0)
                                        {
                                            p.ay *= -1;
                                            down.play_once();
                                        }

                                    }
                                }
                            }

                            sumX = 0;
                            sumY = 0;
                            startX = 0;
                            startY = 0;

                        }
                    }
                    else
                    {
                        if (tl.State == TouchLocationState.Released)
                        {
                            //Touch event in the menu
                            if (currentMode == 1) //Main menu
                            {
                                //100, 420 X
                                //200, 260 Y
                                if (tl.Position.X >= 100 && tl.Position.X <= 420)
                                {
                                    if (tl.Position.Y >= 200 && tl.Position.Y <= 260)
                                    {
                                        currentMode = 2;
                                        menu = null;




                                        prepareLevel(currentLevel);
                                    }
                                    else if (tl.Position.Y >= 280 && tl.Position.Y <= 340)
                                    {
                                        this.Exit();
                                    }

                                }


                            }
                            else if (currentMode == 2 || currentMode ==3)
                            {
                                menu = null;
                                currentMode++;
                                if (currentMode == 3)
                                {
                                    menuSound.stop_sound();
                                    level1S.background_play();
                                }

                            }
                            else if (currentMode >= 4) //Level 1 Screen
                            {

                                if (currentMode == 7)
                                {
                                    level1S.stop_sound();
                                    level4S.background_play();
                                }
                                if (currentMode == 8)
                                {
                                    level4S.stop_sound();
                                    level5S.background_play();
                                }
                                if (currentMode == 9)
                                {
                                    level5S.stop_sound();
                                    level6S.background_play();
                                }

                                menu = null;
                                currentMode = 0;

                                pause = false;
                            }
                        }


                    }
                }
                /*else if(touches.Count == 0)  
                {  
                    touching = false;
                }  */
            }

        }
    }
}
